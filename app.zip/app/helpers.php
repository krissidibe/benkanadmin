<?php

use App\Models\CoorCercle;

if (!function_exists("countInCercle")) {
    function countInCercle($cercle){
        
  $cercleCount =   CoorCercle::where('cercle',"=", $cercle->non)->count();
    return $cercleCount;
    }
   
}

?>