@extends("admin.template")
@section("content")
 
<div class="row">
    <div class="col-md-9">
		
         <div class="x_panel">
								<div class="x_title">
									<h2>Information </h2>
									
									<div class="clearfix"></div>
								</div>
								<div class="x_content">
									<br>
									<form action="{{ route("admin.adhesion.store") }}" method="post" id="demo-form2" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="">
										@method("POST")
										@csrf
										<input readonly type="hidden" name="id" value="{{$adhesion->id}}" >
										<div class="item form-group">
											<label  class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Nom <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->nom}}" name="nom" type="text" id="first-name" required="required" class="form-control ">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Prenom <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->prenom}}" name="prenom" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Organisation <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->inOrganisation}}" name="prenom" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">NINA <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->nina}}" name="prenom" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Carte Electeur <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->carteElec}}" name="prenom" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										 
										
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Mot de passe <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->numero}}" name="password" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Email <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->email}}" name="email" type="email" id="last-name" required="required" class="form-control">
											</div>
										</div>
										    <div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Numero de téléphone <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->numero}}" name="telephone" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Region <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->region}}" name="adresse" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Cerlce / Comune <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->cercleComune}}" name="adresse" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Adresse physique <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input readonly value="{{$adhesion->adresse}}" name="adresse" type="text" id="last-name" required="required" class="form-control">
											</div>
										</div>
										 

									</form>
								</div>
		</div>
</div>
<div class="col-md-3">
     <div class="x_panel">
								<div class="x_title">
									<h2>Carte</h2>
									 
									<div class="clearfix"></div>
								</div>
								<div class="x_content">
									<br>
								 
								</div>
		</div>
</div>
</div>

@if ($message = Session::get('success'))
<div class="alert alert-success alert-dismissible " role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                     <strong>{{ $message }}</strong>
                  </div>
@endif



@endsection