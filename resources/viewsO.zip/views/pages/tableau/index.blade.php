@extends("admin.template")
@section("content")
 
<div class="row">

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Kayes")}}">
      <div class="jumbotron">
    <h3>Kayes</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Koulikoro")}}">
      <div class="jumbotron">
    <h3>Koulikoro</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Sikasso")}}">
      <div class="jumbotron">
    <h3>Sikasso</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Segou")}}">
      <div class="jumbotron">
    <h3>Ségou</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Mopti")}}">
      <div class="jumbotron">
    <h3>Mopti</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Tombouctou")}}">
      <div class="jumbotron">
    <h3>Tombouctou</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Gao")}}">
      <div class="jumbotron">
    <h3>Gao</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Kidal")}}">
      <div class="jumbotron">
    <h3>Kidal</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Koulikoro")}}">
      <div class="jumbotron">
    <h3>Koulikoro</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Taoudenit")}}">
      <div class="jumbotron">
    <h3>Taoudénit</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Menaka")}}">
      <div class="jumbotron">
    <h3>Menaka</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Bougouni")}}">
      <div class="jumbotron">
    <h3>Bougouni</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Dioila")}}">
      <div class="jumbotron">
    <h3>Dioila</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Nioro")}}">
      <div class="jumbotron">
    <h3>Nioro</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Koutiala")}}">
      <div class="jumbotron">
    <h3>Koutiala</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Kita")}}">
      <div class="jumbotron">
    <h3>Kita</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Nara")}}">
      <div class="jumbotron">
    <h3>Nara</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Bandiagara")}}">
      <div class="jumbotron">
    <h3>Bandiagara</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","San")}}">
      <div class="jumbotron">
    <h3>San</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Douentza")}}">
      <div class="jumbotron">
    <h3>Douentza</h3> 
    </div>
    </a>
  </div>

  <div class="col-md-3">
    <a href="{{route("admin.tableau.info","Gourma")}}">
      <div class="jumbotron">
    <h3>Gourma</h3> 
    </div>
    </a>
  </div>



</div>

@endsection