@extends("admin.template")
@section("content")
<h1>ici Post</h1>
@endsection