@extends("admin.template")
@section("content")
<div class="data__view">
    <h1>Accueil</h1>
</div>
@endsection